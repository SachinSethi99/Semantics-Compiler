#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct 27 16:27:20 2021

@author: sachin
"""
#Week 2 Coursework Task B
import antlr4 as antlr
from CoffeeLexer import CoffeeLexer
from CoffeeVisitor import CoffeeVisitor
from CoffeeParser import CoffeeParser
from CoffeeUtil import Var, Method, Import, Loop, SymbolTable

class CoffeeTreeVisitor(CoffeeVisitor):
    def __init__(self):
        self.stbl = SymbolTable()
       
    def visitProgram(self, ctx):
        method = Method('main','int',ctx.start.line)
        self.stbl.pushFrame(method)
        self.visitChildren(ctx)
        self.stbl.popFrame()
       
    def vistBlock(self,ctx):
#        '''
#        The visit block checks the left and right braces, the push scope adds to the scope 
#        then the children gets visited and in the next validation if the block finds the nodes 
#        and then pops them
#        '''
        if(ctx.LCURLY() != None):
            self.stbl.pushScope()
        self.visitChildren(ctx);
        if(ctx.LCURLY() !=None):
            self.stbl.popScope()

    def visitGlobal_decl(self, ctx):
        line = ctx.start.line
        var_type = ctx.var_decl().data_type().getText()
#        """
#        The ctx start line is obtained and so is the (var_type = ctx.var_decl().data_type().getText())  
#        data type (as text), this is so that decl().data_type() prints 
#        the out the data type (ie int, string) this makes it easy to validate when checking for the data type as the .getText gets
#        the literal string under the node (ctx repesents the route node)
#        """
        for i in range (len(ctx.var_decl().var_assign())):
#           I loop through the var assign nodes (also var assign is a list) to get the name of each varible 
#            '''
#            After the for loop I interperate the parse tree and then I assign some varibles which contains the var_id, var_size and the 
#            array. I also peak the var_id to makesure it is on the symbol table. I wanted to add that the var_id contains the element 
#            at the point of i as it indexes the list.
#            ''' 
            var_id = ctx.var_decl().var_assign(i).var().ID().getText()
            var_size = 8
            is_array = False#by deafult it's not an array the if statements will check for this 
#            '''
#            value set 8 bytes and if statement checks the size of the array, by setting it 8 won't have a large impact on 
#            outcome, but for codegen it will cause of the pushing and popping of bytes
#            '''
            
            var = self.stbl.peek(var_id)
            if(var!=None):
                print('Error on line '+line + ', and var '+ var_id+ 'already in the scope on line '+ var.line)
           
#           checking for array
            if (ctx.var_decl().var_assign(i).var().INT_LIT()!=None):
                var_size = int(ctx.var_decl().var_assign(i).var().INT_LIT().getText())*8
                is_array =True
#           semantic rule; array must be greater than 0
            if(var_size <=0):
                print('Error, you cannot have an array of 0 or less')
                
            if(ctx.var_decl().var_assign(i).expr() != None):
                self.visit(ctx.var_decl().var_assign(i).expr())
           
            var = Var(var_id,var_type,var_size,Var.GLOBAL,is_array,line)
            self.stbl.pushVar(var)
#            '''
#            The first check is to see if the var id is there, if it is then we print an errors saying its in the scope. Next to check
#            for the array, the if statement checks for an integer and then if is I get the var size and convert into integer (as it 
#            currently is a string), also by *8 becuase I orgnially set the array to 8 bytes. As the array found I then set the var_array
#            to true. 
#            
#            Next is to validate the array, if the size is less than or equal 0 print an error because we can't have any array which doesn't 
#            having anything inside or returns -1.
#            
#            The next validation it to check where the expression is assigned and then visits it (at each elemant) and collects the details of 
#            of it and then it get put into  Var and pushed into the stack. Also, I've passed in VAR.GLOBAL because I am passing through global 
#            variables because I have validated them
#            '''
                                
   
    def visitVar_decl(self,ctx):
#       visitVar is similar to visitGlobal but it checks through the locals like methods and inside the method
        line = ctx.start.line
        var_type = ctx.data_type().getText()
        var_length= len(ctx.var_assign())
        method_id = ctx.ID().getText()
        var =self.stbl.peek(method_id)
#        '''
#        Obtain the the data such as the data type, length of var (to check for arrays) and the method id. I also peek the method id
#        so that I can validate the method
#        '''
        
        if(var == 'Main'):#check is the method id is main, if it is then I print an error saying the method doesn't exist 
            print('Error on line '+ line+ 'this method '+ method_id + 'do not exist' )
            
#        '''
#        I use a for loop to go through var_length, then I store the element that the loop is assigned to in var_id, I then peek
#        the var_id on the sybmol table. The first validation is to check if the var is there and if it not none then I print it
#        the varible has already beem written. 
#        
#        The next if is the same as in the global method but here I'm going through to check for ints in the method. The if statement checks
#        for an integer and then if is I get the var size and convert into integer (as it currently is a string), 
#        also by *8 becuase I orgnially set the array to 8 bytes. As the array found I then set the var_array to true. 
#        Next is to validate the array, if the size is less than or equal 0 print an error because we can't have any array which doesn't 
#        having anything inside or returns -1.
#            
#        The next validation it to check where the expression is assigned and then visits it (at each elemant) and collects the details of 
#        of it and then it get put into  Var and pushed into the stack. Also, I've passed in VAR.LOCAL because I am passing through local 
#        varibles becuase I have validated them.  
#        '''

        for i in range (var_length):
            var_id = ctx.var_assign(i).var().getText()
            var = self.stbl.peek(var_id)
            
            if(var != None):
                print('Error on' + line + ', same varible writtin '+var_id+ ', ' + var.line)
    
            if(ctx.var_assign(i).var().INT_LIT() !=None):
                var_size = int(ctx.var_assign(i).var().INT_LIT().getText())*8
                var_array = True
                
            if(var_size <=0):#Check array length is less than or equal to 0
                print('Cannot have 0 or less in an array on line '+ line)
            if(ctx.var_decl().var.assign(i).expr() !=None):
                self.visit(ctx.var_decl.var_assign(i).expr())
            
                var = Var(var_id, var_type, 8, Var.LOCAL, var_array, line)
                self.stbl.pushVar(var)
            
                
    
    def visitMethod_decl(self,ctx):
        line = ctx.start.line
        method_id =ctx.ID().getText()
        method_type = ctx.return_type().getText()
#        '''
#        Get the details from tree, and store the id and return type into method_id and method_type. I then chcck if the method
#        exisits by peeking on the sybmol table. I validate this, by checking is the method is not None then print the line
#        saying the method is already there, if the if statement was var == None then I'd print that no method declared. 
#        '''
      
        #TODO: semantic rule 3
        var = self.stbl.peek(method_id)
        if(var != None):
            print('Error on line: '+ line + ' method_id' +method_id + 'already declared on line', line)
#        '''
#        Once the check is complete I create a new method and put method onto the symbol table and add stack frame where adds the 
#        method parameteres.
#        '''    
     
        method = Method(method_id, method_type, line)
        self.stbl.pushMethod(method)
        self.stbl.pushFrame(method)

#        '''
#        I then loop through the parameters and get the details of the parameters. As I've prevously done in the other metbods I
#        get details store them in var_id, var_size etc etc. Then I peek at var_id in the symbol table and validate to see if is
#        there. The if checks if var_id is there then print the paremters is already declared. 
#        
#        After checking if var_id is there I make new var and put the gathered details in the new var and I push the var onto the symbol
#        table. I also push the var_type into the method param so that I can implament semantic rule 6 and 7. The visit block visits the
#        method body and does semantic checks.
#        '''
        
        for i in range(len(ctx.param())):
            var_id = ctx.param(i).ID().getText()
            var_type = ctx.param(i).data_type().getText()
            var_size = 8
            var_array = False
            # TODO: semantic rule 2
            var =self.stbl.peek(var_id)
            if(var!=None):
                print('Error on line '+line + ', ' + var_id + ' is already declared  ')
                
            var = Var(var_id,var_type,var_size,var_array,Var.LOCAL,line)
            self.stbl.pushVar(var)
            method.pushParam(var_type)
        self.visit(ctx.block())
#        '''
#        The next check to get the semantics rules 6 and 7. I check if the method type is void and if there is a method return
#        if there is and then I print an error saying that void method cannot return an expression. 
#        
#        I have an issue where if the method type is void but in the code it just says "return" I shouldn't be getting an error 
#        because I'm not returning anything but when I tested this it sill prints the erorr line. I tested this by chaning the method
#        return == 'return' but an error occured because local varible expr_type is referanced, I wasn't too sure how to go about this
#        
#        The next if statement just checks if method just returns something (like int or bool) and if it does it passes and prints no
#        error.The final validation to check if the method is not void and doesn't have return if these condtions are true then
#        an it will print an error saying a method should return this data type.
#        
#        The popFrame() deltets the stack frame after its been created and validated with the condtions
#        '''
        
        
        #RULE 6 AND 7
        if(method_type == 'void' and method.has_return == True):
            print('Error on line: '+ str(line) + ', void method cannot return an expression')
        elif(method.has_return ==True):
            pass
        
        if(method_type !='void' and method.has_return == False):
            print ('Error: this method should return an '+ method_type.getText())
        
        
        self.stbl.popFrame()
        

            
    def visitExpr(self, ctx):
            if (ctx.literal() != None): 
                return self.visit(ctx.literal())
            elif (ctx.location()!=None):
                return self.visit(ctx.location())
            elif(len(ctx.expr())==2):
                expr0_type=self.visit(ctx.expr(0))
                expr1_type=self.visit(ctx.expr(1))
                if(expr0_type !=expr1_type):
                    
#                   This method visit all the expressions, by looking at the parse tree you can see that the expr has location and literals at either side
#                   of the tree. I first check if there are any literal varibles and if they are then I return them and this is simlar for the location. For
#                   location I just check the location of the varibles and return them they are any.
#                   
#                   The next part is to check length of the expression and if its is equal to 2 then I store the left side of the expression in expr0 and the
#                   right side into expr1. I go through both sides of the expressions and I return the side with highest presdance. 
                 
                    
                    if(expr0_type == 'float'):
                        return expr0_type
                    elif(expr1_type == 'float'):
                        return expr1_type
                    elif(expr0_type == 'bool' and expr1_type != 'bool'):
                        return expr1_type
                    elif(expr1_type == 'bool' and expr0_type!= 'bool'):
                        return expr0_type
                    elif(expr1_type== 'int' and expr0_type== 'float'):
                        return expr0_type
                    elif(expr0_type == 'int' and expr1_type == 'float'):
                        return expr1_type
                    elif(expr1_type == expr0_type):
                        return expr0_type
#                    '''
#                    To return the highest presdance between the expressions I check the data types using the condtions above. So, float has the highest presdance, then int 
#                    and bool in that order.
#                    The if condtions returns highest presdance. 
#                    '''
                    
                else:
                    return expr0_type;
            elif(ctx.data_type() !=None):
                return ctx.data_type().getText();
            else: 
                return self.visitChildren(ctx) 
            
      
####################################################################################################################################################################################################################            
    def visitLiteral(self,ctx):
#        '''
#        I checked for the nodes and what they return, if it is an int literal then I should be expecting an int but it its not then I would be expecting none to be printed back
#        This method would check for the literals (like on the parse tree) then it will check for the datatype and return what the data type is
#        '''
        
#        '''
#        If the literal operator is an int then it will print out operator must be bool found int because it is semantic rule 11 where it should be bool in the brackets of the 
#        if statement
#        '''
#        
        if(ctx.STRING_LIT()!=None):
            return 'string'
        elif (ctx.INT_LIT()!=None):
            print('Error on line:'+str(ctx.start.line)+',operand of logical not operator must be (bool), found (int) ')
            return 'int'
                
        elif (ctx.FLOAT_LIT()!=None):
            return 'float'
            
        elif(ctx.bool_lit()!=None):
            #print('Error on line:'+str(ctx.start.line)+',operand of logical not operator must be (bool), found (int) ')
            pass
        elif (ctx.CHAR_LIT()!=None):
            return 'char'
        
    
      
            
            
#######################################################################################################################################################################################################################           
    def visitLocation(self,ctx):
#        """
#        I check for the varible in right the location, I get the Id of the vairble and peek in the symbol table. Then the validation is to check if the varible is there 
#        in all of the scope and if it is then return that data type. If not I print an error that the varible isn't declared
#        """
        var_id = ctx.ID().getText()
        var = self.stbl.peek(var_id)
        #check varibles is declared in all scope
        if(var!= None):
            #return varible (data type) found 
            return var.data_type
        else:
            print ('Error on line '+ ctx.start.line + ' varible not declared')
#            '''
#            I was going to print the varible id to show which varible isn't declared but I had issues with printing so I decided to gave vague print, I the error number
#            on the line should give a user the indication that the varible doesn't work
#            '''
    
    
#################################################################################################################################################################################################################### 
    def visitReturn(self,ctx):
        #Get the method content and set the return type as true
        line = ctx.start.line 
        method_ctx = self.stbl.getMethodContext()
        method_ctx.has_return = True        
        
        if(ctx.expr() !=None):
            data_type = self.visit(ctx.expr())
            
            if(method_ctx.return_type != data_type):
                print('Error on line: '+ str(line)+', main method should return type int not bool.')
            elif(method_ctx.return_type == data_type):
                print('Warning on line ' +str(line)+': not all branches of if statement return a value')
                
#                The visit return method is where I check the expression in the parse and check the method's return type to see if it matches
#                so if the method return type isn't the same as the data type then I print an error saying what the main method should return.
#                I feel like I have made mistake because as it seams hard coded to me with the error I'm printing out. I've tried and test test.coffee with different
#                values but the right output wasn't printed that why I left that print line there. But if the method return type is the same as the data type 
#                then I just print a warning as it is mentioned in semantic rule 9
       
               


#load source code
filein = open('./test.coffee', 'r')
source_code = filein.read();
filein.close()

#create a token stream from source code
lexer = CoffeeLexer(antlr.InputStream(source_code))
stream = antlr.CommonTokenStream(lexer)

#parse token stream
parser = CoffeeParser(stream)
tree = parser.program()

#create Coffee Visitor object
visitor = CoffeeTreeVisitor()

#visit nodes from tree root
visitor.visit(tree)